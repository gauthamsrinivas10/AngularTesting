import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController  } from '@angular/common/http/testing'
import { RouterTestingModule  } from '@angular/router/testing'
import { UserService } from './user.service';

describe('UserService', () => {
  let service: UserService;
  let httpMock : HttpTestingController

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports : [HttpClientTestingModule , RouterTestingModule]
    });

    service = TestBed.inject(UserService);
    httpMock = TestBed.inject(HttpTestingController);
    
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('Login call to be tested be created', () => {
    service.login("abc@edu.co" , "1234")
    const req = httpMock.expectOne("http://localhost:3000/api/v1/login")
    req.flush ( { accessToken : "abc.123.xyz"})
    service.userinfo.subscribe((data)=>{
      console.log(data)
      expect(data.accessToken).toBe("abc.123.xyz")
    })
   
  });
});
