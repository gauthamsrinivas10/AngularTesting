import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginFormComponent } from './login-form.component';
import { UserService } from "../../services/user.service"
import { of } from 'rxjs';
import { FormsModule , NgForm } from "@angular/forms"
import { By } from '@angular/platform-browser';

const validLoginForm = <NgForm> {
  value : {
    email : "abc@edu.co",
    password : "1234"
  }
}

describe('LoginFormComponent', () => {
  let component: LoginFormComponent;
  let fixture: ComponentFixture<LoginFormComponent>;
 let userServiceMock : Partial<UserService>
let userService;

  beforeEach(async () => {
userServiceMock = {
  login: function() : any {
    return of({})
  }
}
  
  

    await TestBed.configureTestingModule({
      declarations: [ LoginFormComponent ] ,
      providers : [ { provide : UserService , useValue : userServiceMock }] ,
      imports : [FormsModule]
    })
    .compileComponents();

    userService = TestBed.inject(UserService)

  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  
  it('should call loginUserMethod ', () => {
     component.changeContent();
    fixture.detectChanges();
    component.showContent
    expect(component.showContent).toBeFalsy()
    expect(fixture.debugElement.queryAll(By.css(".test-content")).length).toBe(0);
  });
});
