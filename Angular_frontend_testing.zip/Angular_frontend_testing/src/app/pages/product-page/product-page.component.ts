import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-product-page',
  templateUrl: './product-page.component.html',
  styleUrls: ['./product-page.component.css']
})
export class ProductPageComponent implements OnInit {

  constructor(private products : ProductsService) { }

  ngOnInit(): void {
    this.products.getProducts().subscribe((data : any)=>{
      console.log(data, "ProductPageComponent")
    }
    );

  }

}
